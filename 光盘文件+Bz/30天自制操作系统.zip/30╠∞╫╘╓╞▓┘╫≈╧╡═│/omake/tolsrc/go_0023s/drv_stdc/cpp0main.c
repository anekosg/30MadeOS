/* copyright(C) 2003 H.Kawai (under KL-01). */

#define SIZ_STDOUT			(2 * 1024 * 1024)
#define SIZ_STDERR			(16 * 1024)
#define SIZ_WORK			(8 * 1024 * 1024)
#define SIZ_SYSWRK			(2 * 1024 * 1024)

#include "cc1drv.c"
