
/* !kawai! */
#ifdef IN_GCC
# include "../config/i386-protos.h"
#endif
#include "tm-preds.h"
/* end of !kawai! */
